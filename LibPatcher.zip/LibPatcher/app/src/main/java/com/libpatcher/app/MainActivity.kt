package com.libpatcher.app

import android.app.Activity
import android.content.Intent
import androidx.core.content.FileProvider
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Date
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.math.BigInteger

class MainActivity : ComponentActivity() {
    private var apkUri: Uri? = null
    private var soUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var apkButton: Button
    private lateinit var soButton: Button
    private lateinit var patchButton: Button

    private val pickApk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { apkUri = uri; apkButton.text = "APK selected ✓"; refreshStatus() }
    }
    private val pickSo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { soUri = uri; soButton.text = ".SO selected ✓"; refreshStatus() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(15, 18, 27)
        window.navigationBarColor = android.graphics.Color.rgb(15, 18, 27)
        window.decorView.systemUiVisibility = 0
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(22))
            setBackgroundColor(android.graphics.Color.rgb(15, 18, 27))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val title = TextView(this).apply {
            text = "LibPatcher"; textSize = 29f; setTextColor(-1); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "ANDROID • ARM64"; textSize = 11f; letterSpacing = .16f
            setTextColor(0xff9aa4b2.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(28))
        }
        content.addView(subtitle, matchWrap())
        apkButton = makeButton("UPLOAD APK") { pickApk.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream")) }
        soButton = makeButton("UPLOAD .SO") { pickSo.launch(arrayOf("application/octet-stream", "*/*")) }
        patchButton = makeButton("PATCH APK", true) { patch() }
        content.addView(sectionLabel("1  •  GAME APK"), matchWrap())
        content.addView(apkButton, matchWrap().apply { bottomMargin = dp(22) })
        content.addView(sectionLabel("2  •  ARM64 LIBRARY"), matchWrap())
        content.addView(soButton, matchWrap().apply { bottomMargin = dp(30) })
        content.addView(patchButton, matchWrap())
        status = TextView(this).apply {
            text = "Waiting for files"; textSize = 13f; setTextColor(0xff9aa4b2.toInt())
            gravity = Gravity.CENTER; setPadding(0, dp(22), 0, 0)
        }
        content.addView(status, matchWrap())
        val note = TextView(this).apply {
            text = "Adds the selected library to lib/arm64-v8a and signs a new APK. The game must already load that library."
            textSize = 12f; setTextColor(0xff7f8998.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        content.addView(note, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun sectionLabel(s: String) = TextView(this).apply {
        text = s; textSize = 12f; setTextColor(0xffc5ceda.toInt())
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(dp(2), 0, 0, dp(9))
    }

    private fun makeButton(label: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f
        setTextColor(-1)
        backgroundTintList = android.content.res.ColorStateList.valueOf(if (primary) 0xff2563eb.toInt() else 0xff242d3c.toInt())
        minHeight = dp(54); setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun refreshStatus() { status.text = if (apkUri != null && soUri != null) "Both files selected • Ready to patch" else "Select an APK and an ARM64 .so file" }

    private fun patch() {
        val a = apkUri; val s = soUri
        if (a == null || s == null) { toast("Select both files first"); return }
        patchButton.isEnabled = false
        status.text = "Patching and signing…"
        Thread {
            try {
                val apk = copyToCache(a, "input.apk")
                val lib = copyToCache(s, "library.so")
                require(lib.name.endsWith(".so", true)) { "The library must be a .so file" }
                validateArm64Elf(lib)
                val outputUnsigned = File(cacheDir, "patched-unsigned.apk")
                val outputSigned = File(getExternalFilesDir(null), "LibPatcher-patched.apk")
                insertLibrary(apk, lib, outputUnsigned)
                signApk(outputUnsigned, outputSigned)
                val verifier = ApkVerifier.Builder(outputSigned).build().verify()
                check(verifier.isVerified) { "APK signature verification failed" }
                runOnUiThread {
                    status.text = "Patch complete • Opening Android installer…"
                    toast("Patch complete. Confirm installation in Android.")
                    patchButton.isEnabled = true
                    openInstaller(outputSigned)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Patch failed: ${e.message ?: "Unknown error"}"; toast("Patch failed") ; patchButton.isEnabled = true }
            }
        }.start()
    }

    private fun copyToCache(uri: Uri, name: String): File {
        val out = File(cacheDir, name)
        contentResolver.openInputStream(uri).use { input -> requireNotNull(input) { "Cannot open selected file" }; FileOutputStream(out).use { input.copyTo(it) } }
        return out
    }

    private fun validateArm64Elf(file: File) {
        FileInputStream(file).use { input ->
            val h = ByteArray(20); require(input.read(h) == 20) { "Library is too small" }
            require(h[0] == 0x7f.toByte() && h[1] == 0x45.toByte() && h[2] == 0x4c.toByte() && h[3] == 0x46.toByte()) { "Selected .so is not an ELF library" }
            require(h[4].toInt() == 2) { "Library is not 64-bit" }
            val machine = (h[18].toInt() and 255) or ((h[19].toInt() and 255) shl 8)
            require(machine == 183) { "Library is not ARM64 (AArch64)" }
        }
    }

    private fun insertLibrary(apk: File, lib: File, out: File) {
        val target = "lib/arm64-v8a/${lib.name}"
        var replaced = false
        ZipInputStream(FileInputStream(apk)).use { zin ->
            ZipOutputStream(FileOutputStream(out)).use { zout ->
                var entry = zin.nextEntry
                while (entry != null) {
                    val name = entry.name
                    val signatureFile = name.startsWith("META-INF/", true) &&
                        (name.endsWith(".SF", true) || name.endsWith(".RSA", true) || name.endsWith(".DSA", true) || name.endsWith(".EC", true) || name.equals("META-INF/MANIFEST.MF", true))
                    if (name != target && !signatureFile) {
                        val ne = ZipEntry(name).apply { time = entry.time }
                        zout.putNextEntry(ne)
                        if (!entry.isDirectory) zin.copyTo(zout)
                        zout.closeEntry()
                    } else if (name == target) replaced = true
                    zin.closeEntry(); entry = zin.nextEntry
                }
                val added = ZipEntry(target)
                zout.putNextEntry(added); FileInputStream(lib).use { it.copyTo(zout) }; zout.closeEntry()
            }
        }
    }

    private fun signingIdentity(): Pair<PrivateKey, X509Certificate> {
        val file = File(filesDir, "libpatcher-signing.p12")
        val password = "local-libpatcher-key".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        if (file.exists()) FileInputStream(file).use { ks.load(it, password) } else ks.load(null, password)
        if (!ks.containsAlias("patcher")) {
            val gen = KeyPairGenerator.getInstance("RSA"); gen.initialize(2048)
            val pair = gen.generateKeyPair(); val now = System.currentTimeMillis()
            val name = X500Name("CN=LibPatcher Local Signing")
            val builder = JcaX509v3CertificateBuilder(name, BigInteger.valueOf(now), Date(now - 86400000L), Date(now + 20L * 365 * 86400000L), name, pair.public)
            val signer = JcaContentSignerBuilder("SHA256withRSA").build(pair.private)
            val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
            ks.setKeyEntry("patcher", pair.private, password, arrayOf(cert))
            FileOutputStream(file).use { ks.store(it, password) }
        }
        return (ks.getKey("patcher", password) as PrivateKey) to (ks.getCertificate("patcher") as X509Certificate)
    }

    private fun signApk(input: File, output: File) {
        val (key, cert) = signingIdentity()
        val signer = ApkSigner.SignerConfig.Builder("libpatcher", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer)).setInputApk(input).setOutputApk(output).setMinSdkVersion(26).build().sign()
    }

    private fun openInstaller(apk: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.provider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(intent) }
        catch (_: Exception) { status.text = "Patched APK saved to Android/data/$packageName/files. Enable permission to install unknown apps, then try again." }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
