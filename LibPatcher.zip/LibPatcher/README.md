# LibPatcher (Android ARM64)

A small Android app project that selects an APK and an ARM64 `.so`, inserts the library into `lib/arm64-v8a/`, then signs the rebuilt APK with a locally generated signing identity.

## Build

1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The app module is configured with `abiFilters += "arm64-v8a"`.

## Important behavior

- The selected library is checked for ELF64 and AArch64 (`e_machine = 183`).
- Existing APK signature metadata is removed before the APK is rebuilt and re-signed.
- The output is signed with a locally generated key stored in the app's private files directory. Android treats this as a different signing identity from the original game, so it generally cannot update/replace an already-installed copy signed by the original developer. Uninstalling the original app may be necessary, which can remove its local data.
- The library is inserted as a ZIP entry only. This does **not** add code to load it. The game must already load that exact library name (or have another authorized loader mechanism).
- This project does not bypass licensing, integrity checks, anti-cheat, or access controls.

## Requirements

- Android Studio with JDK 17
- Android SDK Platform 35
- Android device running Android 8.0 or newer
- After patching, the app launches Android's package installer. The user must confirm installation and allow LibPatcher to install unknown apps in Android settings if prompted.
