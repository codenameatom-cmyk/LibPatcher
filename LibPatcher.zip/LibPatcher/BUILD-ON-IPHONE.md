# Build LibPatcher from an iPhone using GitHub Actions

1. In Safari, sign in to GitHub and create a **new private repository** named `LibPatcher`.
2. On the repository page, choose **Add file → Upload files**.
3. Upload the *contents* of this `LibPatcher` folder (including the hidden `.github` folder if the mobile file picker allows it), then commit to `main`.
4. Open the repository's **Actions** tab. Select **Build LibPatcher APK** and tap **Run workflow** if it has not started automatically.
5. Wait for the run to finish with a green check. Open the run, scroll to **Artifacts**, and download `LibPatcher-debug-apk`.
6. The artifact is a ZIP. Open it in the iPhone Files app to extract `app-debug.apk`. Transfer that APK to an Android device to install it; iOS cannot install Android APKs.

If GitHub's mobile upload interface hides `.github`, use Safari's **Request Desktop Website** or upload the project from a computer. Do not publish signing keys or private credentials in the repository.

This workflow builds a debug APK. The app's library insertion only places the `.so` in the APK; it does not make a game load the library unless the game already has a compatible loader for that library name.
